
angular
.module('app', ['ngMessages'])
.controller('PaymentCtrl', PaymentCtrl);

function PaymentCtrl() {}