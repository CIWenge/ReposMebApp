import {Injectable} from '@angular/core';
import {NavigationEnd, Router} from '@angular/router';
import {UserService} from '../Shared/User.service';
//import {GetClientData} from '../Shared/GetClientData.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import {
  Member, MemberDependentPayment, FormNumbers, MemberPaymentMethod,
  Product, GetRatesByCvgType, FormNumberDetails
} from './User.model';

declare var ga: Function;

@Injectable({
  providedIn: 'root'
})
export class GoogleAnalyticsService {
  constructor(public router: Router, private userService: UserService, private http: HttpClient) {
  
    // this.router.events.subscribe(event => {
    //   try {
    //     if (typeof ga === 'function') {
    //       if (event instanceof NavigationEnd) {
    //         ga('create', 'UA-123346199-1', 'auto');
    //         ga('set', 'page', event.urlAfterRedirects);
    //         ga('send', 'pageview');
    //         console.log('%%% Google Analytics page view event %%%');
    //         alert(userService.prdctobj.EffectiveDate);
    //       }
    //     }
    //   } catch (e) {
    //     console.log(e);
    //   }
    // });

  }

  public gaTriggerPageView(uaCode: string, pageName: string)
  {   
    if(uaCode !== null && uaCode.length > 0)
    {
      try {
        if (typeof ga === 'function') {          
           
            ga('create', uaCode, 'auto');
            ga('set', 'page', pageName);
            ga('send', 'pageview');
            console.log('%%% Google Analytics page view event %%%');
            // alert(this.userService.objFormnumbers.AgentName);
          }
        
      } catch (e) {
        console.log(e);
      }
    } 
   
  }

  public eventSubscribe(uaCode: string)
  {
    this.router.events.subscribe(event => {
      try {
        if (typeof ga === 'function') {
          if (event instanceof NavigationEnd) {
            // ga('create', 'UA-123346199-1', 'auto');
            ga('create', uaCode, 'auto');
            ga('set', 'page', event.urlAfterRedirects);
            ga('send', 'pageview');
            console.log('%%% Google Analytics page view event %%%');
            // alert(this.userService.objFormnumbers.AgentName);
          }
        }
      } catch (e) {
        console.log(e);
      }
    });
  }

  objFormnumbers: FormNumbers;
  objRates: GetRatesByCvgType[];

 

  /**
   * Emit google analytics event
   * Fire event example:
   * this.emitEvent("testCategory", "testAction", "testLabel", 10);
   * @param {string} eventCategory
   * @param {string} eventAction
   * @param {string} eventLabel
   * @param {number} eventValue
   */
  public emitEvent(eventCategory: string,
   eventAction: string,
   eventLabel: string = null,
   eventValue: number = null) {
    if (typeof ga === 'function') {
      ga('send', 'event', {
        eventCategory: eventCategory,
        eventLabel: eventLabel,
        eventAction: eventAction,
        eventValue: eventValue
      });
    }
  }


}