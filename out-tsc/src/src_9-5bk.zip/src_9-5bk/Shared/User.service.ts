
import { Injectable } from '@angular/core';
import {
  Member, MemberDependentPayment, FormNumbers, MemberPaymentMethod,
  Product, GetRatesByCvgType, FormNumberDetails
} from './User.model';

import { Activesteps } from '../app/activesteps.enum';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  public activesteps;// = Activesteps.stepone;

  constructor() {
    
  }

  mbrobj: Member = new Member();
  pymntobj: MemberPaymentMethod = new MemberPaymentMethod();
  prdctobj: Product = new Product();

  ombrdepobj: MemberDependentPayment = new MemberDependentPayment();

  objFormnumbers: FormNumbers = new FormNumbers();
  objRates: GetRatesByCvgType = new GetRatesByCvgType();
  objFormNumberDetails: FormNumberDetails = new FormNumberDetails();

  Member(user: Member) {
    this.mbrobj.FirstName = user.FirstName;
    this.mbrobj.LastName = user.LastName,
      this.mbrobj.Email = user.Email,
      this.mbrobj.MailingAddress = user.MailingAddress,
      this.mbrobj.Address1 = user.MailingAddress,
      this.mbrobj.Address2 = user.Address2,
      this.mbrobj.City = user.City,
      this.mbrobj.StateCode = 'TX', // user.StateCode,
      this.mbrobj.ZipCode = user.ZipCode,
      this.mbrobj.DOB = '06/06/2005',
      this.mbrobj.MobilePhone = user.MobilePhone,
      this.mbrobj.WorkPhone = user.WorkPhone,
      this.mbrobj.HomePhone = user.HomePhone,
      this.mbrobj.Gender = user.Gender,
      this.mbrobj.MemberRecordID = null, // user.MemberRecordID,
      this.mbrobj.ExternalMemberID = '78987A', // user.ExternalMemberID,
      this.mbrobj.ExternalGroupID = null, // user.ExternalGroupID,,
      this.mbrobj.PolicyNumber = '1299584788', // user.PolicyNumber,
      this.mbrobj.GroupCode = 'DEMQBI-D', // user.GroupCode,
      this.mbrobj.GroupAgentID = null, // user.GroupAgentID,
      this.mbrobj.PromoCode = null, // user.PromoCode,
      this.mbrobj.NamePrefix = null, // user.NamePrefix,
      this.mbrobj.MiddleInitial = null, // user.MiddleInitial,
      this.mbrobj.NameSuffix = null, // user.NameSuffix,
      this.mbrobj.CoverageType = 'M', // user.CoverageType,
      this.mbrobj.Language = 'EN', // user.Language,
      this.mbrobj.ReferralCode = 'WEB', // user.ReferralCode,
      this.mbrobj.CancelEffectiveDate = null, // user.CancelEffectiveDate,
      this.mbrobj.TrueEffectiveDt = null, // user.TrueEffectiveDt,
      this.mbrobj.TrueTermDate = null, // user.TrueTermDate,
      this.mbrobj.MbrStatus = 'A', // user.MbrStatus,
      this.mbrobj.ApprovalDt = '07/26/2018', // user.ApprovalDt,
      this.mbrobj.CompanyCode = 'TX', // user.CompanyCode,
      this.mbrobj.CoverageStartDate = '07/26/2018'; // user.CoverageStartDate;
    this.mbrobj.DepFirstName = user.DepFirstName;
    this.mbrobj.DepLastName = user.DepLastName;
    this.mbrobj.DepDOB = '07/05/2018';
    this.mbrobj.Relation = user.Relation;
    this.ombrdepobj.Member = this.mbrobj;
  }

  Products(Rates: GetRatesByCvgType) {

    this.prdctobj.Coverage = Rates.CvgType;
    this.prdctobj.EnrollmentFee = Rates.EnrollmentFee;
    if (Rates.Frequency === 'annual') {
      this.prdctobj.Frequency = 'A';
    }
    if (Rates.Frequency === 'month') {
      this.prdctobj.Frequency = 'M';
    }
    if (Rates.Frequency === 'quarter') {
      this.prdctobj.Frequency = 'Q';
    }
    if (Rates.Frequency === 'semiannual') {
      this.prdctobj.Frequency = 'S';
    }
    this.prdctobj.EffectiveDate = '08/01/2018';
    // this.prdctobj.GroupCode = Rates.;
    this.prdctobj.MemberRate = Rates.CvgRates;
    // this.prdctobj.CompanyCode = Rates.;
    // this.prdctobj.Referral = Rates.CvgType;
    this.ombrdepobj.Product = this.prdctobj;
  }

  MemberPaymentMethod(paymentdetails: MemberPaymentMethod) {

    this.pymntobj.ActNum = paymentdetails.ActNum;
    this.pymntobj.CardActType = paymentdetails.CardActType;//'D';
    this.pymntobj.NameofBank = paymentdetails.NameofBank;
    this.pymntobj.NameonAccount = paymentdetails.NameonAccount;
    this.pymntobj.RoutingNum = paymentdetails.RoutingNum;//'111000753';
    this.pymntobj.Test_Request = null;
    this.pymntobj.CardNumber = paymentdetails.CardNumber;
    this.pymntobj.CardType = null;
    this.pymntobj.CardHolderName = paymentdetails.CardHolderName;
    this.pymntobj.CardExpDate = paymentdetails.CardExpDate;
    this.pymntobj.CardLastFour = null;
    this.pymntobj.DiffBillingAddress = null;
    this.pymntobj.CardAddress = null;
    this.pymntobj.KeyCode = null;
    this.pymntobj.KeyRef = null;
    this.pymntobj.PaymentDate = null;
    this.pymntobj.GatewayName = null;
    this.pymntobj.LoginID = null;
    this.pymntobj.TransactionID = null;
    this.pymntobj.TransactionUrl = null;
    this.pymntobj.Gateway = null;
    this.ombrdepobj.MemberPaymentMethod = this.pymntobj;
  }

  getStep() : Activesteps {
    return this.activesteps;
  }

  setStep(Activesteps : Activesteps){
    this.activesteps = Activesteps;
  }

  FormNumberProperty (frmNumbers: FormNumbers) {
    this.objFormnumbers.AgentName = frmNumbers.AgentName;
    this.objFormnumbers.GoogleAnalyticsUAcode = frmNumbers.GoogleAnalyticsUAcode;
  }

}
