import { Injectable } from '@angular/core';
import {
  Member, MemberDependentPayment, FormNumbers, MemberPaymentMethod,
  Product, GetRatesByCvgType, FormNumberDetails
} from './User.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import {UserService} from '../Shared/User.service';

@Injectable({
  providedIn: 'root'
})
export class GetClientData {

  constructor(private http: HttpClient, private userService: UserService) {

    this.getRestItems();
    this.userService.Products(this.Rates);
    alert('available now!!');
  }
  
  Rates: GetRatesByCvgType = new GetRatesByCvgType();
  objFormNumberDetails: FormNumberDetails;
  objFormnumbers: FormNumbers;
  objRates: GetRatesByCvgType[];
  ObjRate: GetRatesByCvgType;

  BillRate: string;
  CvgType: string;
  EnrollmentFee: string;
  Frequency: string;

  readonly rootUrl = 'http://10.74.11.102/CareAPIServices/GetFormNumberDetails';
  response: any = {};
  getRestItems(): void {
    this.restItemsServiceGetRestItems()
      .subscribe(
        restItems => {
          this.response = restItems;
          this.AssignFormNumbersData(this.response);
          console.log(this.response);
        }
      );
  }

  restItemsServiceGetRestItems() {
    let headers = new HttpHeaders();
    headers = headers.set('x-api-key', 'W3y2ZUFQSVNlcnZpY2VzOkphbjIwMNf=');
    this.objFormnumbers.WebsiteURL = 'www.dentrite.com';
    return this.http
      .post(this.rootUrl, this.objFormnumbers, { headers: headers })
      .pipe(map(data => data));
  }

  AssignFormNumbersData(response: any) {
    this.objFormnumbers.AgentName = this.response['Result'][0].AgentName;
    this.objFormnumbers.AgentProductList = this.response['Result'][0].AgentProductList;
    this.objFormnumbers.AgentProductListSpanish = this.response['Result'][0].AgentProductListSpanish;
    this.objFormnumbers.EnrollmentFee = this.response['Result'][0].EnrollmentFee;
    this.objFormnumbers.ApplicationName = this.response['Result'][0].ApplicationName;

    const goodResponse = [];
    for (let i = 0; i < response['Result'][0].GetRatesByCvgType.length; i++) {
      goodResponse.push(response['Result'][0].GetRatesByCvgType[i]);
    }
    this.objRates = goodResponse;
    console.log(goodResponse);
  }

}
