export class MemberDependentPayment {
    Member;
    MemberPaymentMethod;
    Product;
}


export class Member {

    FirstName: string;
    LastName: string;
    MailingAddress: string;
    Address1: string;
    Address2: string;
    City: string;
    StateCode: string;
    ZipCode: string;
    DOB: string;
    MobilePhone: string;
    WorkPhone: string;
    HomePhone: string;
    Gender: string;
    Email: string;
    Suffix :string;
    PhoneNumber:string;
    PhoneNumberType : string;
    MemberRecordID: string;
    ExternalMemberID: string;
    ExternalGroupID: string;
    PolicyNumber: string;
    GroupCode: string;
    GroupAgentID: string;
    PromoCode: string;
    NamePrefix: string;
    MiddleInitial: string;
    NameSuffix: string;
    CoverageType: string;
    Language: string;
    ReferralCode: string;
    CancelEffectiveDate: string;
    TrueEffectiveDt: string;
    TrueTermDate: string;
    MbrStatus: string;
    ApprovalDt: string;
    CompanyCode: string;
    CoverageStartDate: string;

    DepFirstName: string;
    DepLastName: string;
    Relation: string;
    DepDOB: string;
}

export class Billing {
    CoverageType: string;
    CoverageRate: string;
    CoverageFrequency: string;
}

export class MemberPaymentMethod {
    CardActType: string;
    PaymentFrequency: string;
    EffectiveDate: string;
    NameofBank: string;
    NameonAccount: string;
    ActNum: string;
    RoutingNum: string;
    Test_Request: string;
    CardNumber: string;
    CardType: string;
    CardHolderName: string;
    CardExpDate: string;
    CardLastFour: string;
    DiffBillingAddress: string;
    CardAddress: string;
    KeyCode: string;
    KeyRef: string;
    PaymentDate: string;
    GatewayName: string;
    LoginID: string;
    TransactionID: string;
    TransactionUrl: string;
    Gateway: string;
}

export class Product {
    Coverage: string;
    Frequency: string;
    EffectiveDate: string;
    ProductKey: string;
    GroupCode: string;
    ClientCode: string;
    EnrollmentFee: string;
    MemberRate: string;
    CompanyCode: string;
    Referral: string;


}
export class FormNumberDetails {
    FormNumbers;
    GetRatesByCvgType;
}

export class FormNumbers {
    FormNumbersCode: string;
    AgentName: string;
    AgentProductList: string;
    AgentProductListSpanish: string;
    EnrollmentFee: string;
    ApplicationName: string;
    WebsiteURL: string;
    GroupCode: string;
    CmpCode: string;
    PromoCodeProp: string;
    ReferralCodeProp: string;
    EffDtSelectionProp: string;
    MarketingPlanName: string;
    MarketingPlanNameSpanish: string;
    PromoCode: string;
    StyleSheet: string;
    EffectiveDate: string;
    ReferralCode: string;
    GoogleAnalyticsUAcode: string;
    Analytics: string;
}

export class GetRatesByCvgType {
    MonthlyRate: string;
    QuarterlyRate: string;
    SemiAnnualRate: string;
    AnnualRate: string;
    CvgType: string;
    CvgRates: string;
    EnrollmentFee: string;
    Frequency: string;
}

export class ValidationRules {
    FieldName: string;
    RegExpression: string;
}
