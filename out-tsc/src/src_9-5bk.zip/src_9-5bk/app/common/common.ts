import { UserService } from '../../Shared/User.service';
import { Activesteps } from '../activesteps.enum';

export abstract class CommonComponent {
    
    public UserSrv : UserService;
    public activesteps = Activesteps;

    constructor(private data: UserService) { 
      this.UserSrv = data;
    }
     //To trace the step 
    protected setStep(Activesteps:Activesteps)
    {
      this.data.setStep(Activesteps); 
    }
       
  }
