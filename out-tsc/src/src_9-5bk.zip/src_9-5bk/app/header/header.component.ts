
import { Component, OnInit, OnChanges } from '@angular/core';
import { UserService } from '../../Shared/User.service';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppComponent } from '../app.component';
import { Activesteps } from '../activesteps.enum';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit {
  UserSrv: UserService;
  activesteps: Activesteps; 
  public Activesteps = Activesteps;

  constructor(private data: UserService ,private route: ActivatedRoute, private router: Router,
    private http: HttpClient, appComp: AppComponent) {

    this.UserSrv = data;

   }


  ngOnInit() {

    this.activesteps = this.UserSrv.getStep();
  
  }
  

}
