import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Mbr } from '../User';
import { AppComponent } from '../app.component';
import { Member } from '../../Shared/User.model';
import { UserService } from '../../Shared/User.service';
import { CommonComponent } from '../common/common';
import { Activesteps } from '../activesteps.enum';
import { GoogleAnalyticsService} from '../../Shared/GoogleAnalytics.service';



@Component({
  selector: 'app-wizardsteptwo',
  templateUrl: './wizardsteptwo.component.html',
  styleUrls: ['./wizardsteptwo.component.css'],
})

export class WizardsteptwoComponent extends CommonComponent implements OnInit {
  title = 'Step 2: Member Information';
  user: Member = new Member();
  public No = false;
  public RadioType: any = 'No';
  public NO = false;
  public Buttontype: any = 'NO';
  isOn :boolean;
  select :any;
  isDepOn:any;
  constructor(private userService: UserService, private route: ActivatedRoute, private router: Router, appComp: AppComponent, private googleAnalyticsService: GoogleAnalyticsService) {
    
    super(userService);
    this.user = appComp.member;


   }

    ngOnInit () {  
      super.setStep(Activesteps.steptwo);
      this.googleAnalyticsService.gaTriggerPageView(this.userService.objFormnumbers.GoogleAnalyticsUAcode,'StepTwo Member Info Page!' + this.userService.objFormnumbers.AgentName);
    }

 returnToStep1() {
   this.router.navigate(['']);
 }

 continueToStep3(user) {

   this.userService.Member(user);
   this.router.navigate(['stepthree']);
   
}

}



