import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WizardsteptwoComponent } from './wizardsteptwo.component';



describe('WizardsteptwoComponent', () => {
  let component: WizardsteptwoComponent;
  let fixture: ComponentFixture<WizardsteptwoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WizardsteptwoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WizardsteptwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
