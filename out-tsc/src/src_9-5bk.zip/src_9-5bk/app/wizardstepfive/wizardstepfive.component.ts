import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppComponent } from '../app.component';
import { UserService } from '../../Shared/User.service';
import { HttpClient} from '@angular/common/http';
import { FormNumberDetails} from '../../Shared/User.model';
import { Member, MemberDependentPayment, MemberPaymentMethod,
        Product, GetRatesByCvgType, FormNumbers } from '../../Shared/User.model';
import { Activesteps } from '../activesteps.enum';
import { CommonComponent } from '../common/common';
import { GoogleAnalyticsService } from '../../Shared/GoogleAnalytics.service';

@Component({
  selector: 'app-wizardstepfive',
  templateUrl: './wizardstepfive.component.html',
  styleUrls: ['./wizardstepfive.component.css']
})

export class WizardstepfiveComponent extends CommonComponent implements OnInit {
  title = 'Thank you for your purchase!';
  dateArrival: Date;
  ombrdepobj: MemberDependentPayment;
  mbrObj: Member;
  rateObj: GetRatesByCvgType;
  pymntObj: MemberPaymentMethod;
  prdctObj: Product;
  objFormNumberDetails: FormNumberDetails;
  objFormnumbers: FormNumbers;
  user: Member;
  Rates: GetRatesByCvgType;
  pymnt: MemberPaymentMethod;
  prdt: Product;

  constructor(private userService: UserService, private route: ActivatedRoute,private googleAnalyticsService: GoogleAnalyticsService,
    private http: HttpClient, private router: Router, appComp: AppComponent) {

    super(userService);
    this.ombrdepobj = userService.ombrdepobj;
    this.mbrObj = this.ombrdepobj.Member;
    this.user = this.ombrdepobj.Member;
    this.objFormNumberDetails = userService.objFormNumberDetails;
    this.rateObj = this.objFormNumberDetails.GetRatesByCvgType;
    this.pymntObj = this.ombrdepobj.MemberPaymentMethod;
    this.pymnt = this.ombrdepobj.MemberPaymentMethod;
    this.prdctObj = this.ombrdepobj.Product;
    this.prdt = this.ombrdepobj.Product;
    this.Rates = appComp.rates;
    this.objFormnumbers = appComp.Formnumbers;

    }

  ngOnInit() {
    this.dateArrival = new Date();
    super.setStep(Activesteps.stepfive);
    this.googleAnalyticsService.gaTriggerPageView(this.userService.objFormnumbers.GoogleAnalyticsUAcode,'StepFive Confirmation Page!' + this.userService.objFormnumbers.AgentName);

  }
 
}
 