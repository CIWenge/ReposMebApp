import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WizardstepfiveComponent } from './wizardstepfive.component';

describe('WizardstepfiveComponent', () => {
  let component: WizardstepfiveComponent;
  let fixture: ComponentFixture<WizardstepfiveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WizardstepfiveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WizardstepfiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
