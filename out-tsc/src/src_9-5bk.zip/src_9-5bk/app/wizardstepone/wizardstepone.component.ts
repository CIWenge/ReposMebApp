import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { AppComponent } from '../app.component';
import { UserService } from '../../Shared/User.service';
import { FormNumberDetails, GetRatesByCvgType, FormNumbers, ValidationRules } from '../../Shared/User.model';
import { CommonComponent } from '../common/common';
import { Activesteps } from '../activesteps.enum';
import { DatePipe } from '@angular/common';
import { GoogleAnalyticsService} from '../../Shared/GoogleAnalytics.service';
@Component({
  selector: 'app-wizardstepone',
  templateUrl: './wizardstepone.component.html',
  styleUrls: ['./wizardstepone.component.css']

})
export class WizardsteponeComponent extends CommonComponent implements OnInit {
  title = 'Step 1: Billing Options';

  //#region Declaration
  Rates: GetRatesByCvgType = new GetRatesByCvgType();
  objFormNumberDetails: FormNumberDetails;
  objFormnumbers: FormNumbers;
  objValidationRules: ValidationRules;
  public objRates: GetRatesByCvgType[];
  objValidate: ValidationRules[];

  public CvgRate: string;
  public CvgType: string;
  public EnrollmentFee: string;
  public Frequency: string;
  public sErrorMsg: string;
  public selectedEffectiveDt: string;
  NextMonthDt: Date;
  CurrDt: Date;
  NxtMonthDtstring: string;
  checkedevent;
  pipe = new DatePipe('en-US'); // Use your own locale

  public bPageValid: boolean;
  public bEnrollmentFee: boolean;
  public bPromocode: boolean;
  public bReferralCode: boolean;
  public bEffDtSelection: boolean;
  public bbtnStepOne: boolean;
  public bValidPromoCode: boolean;
  public bValidReferralCode: boolean;
  public bReqEffDt: boolean;
  public bReqPromoCode: boolean;
  public bReqReferralCode: boolean;

  //#endregion

  //Calling GetValidationRules API for server side validation
  readonly rootGetValidationUrl = 'http://10.74.11.102/CareAPIServices/GetValidationRules';
  responsevalidation: any = {};
  getValidationRules(): void {
    this.restItemsServiceGetValidation()
      .subscribe(
        restItems => {
          this.responsevalidation = restItems;
          this.AssignValidationRules(this.responsevalidation);
        }
      );
  }
  AssignValidationRules(ValidationRuleRes: any) {
    const Validation = [];
    for (let i = 0; i < ValidationRuleRes['Result'].length; i++) {
      Validation.push(ValidationRuleRes['Result'][i]);
    }
    this.objValidate = Validation;
    console.log(this.objValidate);
  }

  //Calling GetValidationRules API for server side validation
  readonly rootUrl = 'http://10.74.11.102/CareAPIServices/GetFormNumberDetails';
  response: any = {};
  getRestItems(): void {
    this.restItemsServiceGetRestItems()
      .subscribe(
        restItems => {
          this.response = restItems;
          this.AssignFormNumbersData(this.response);
          console.log(this.response);
        }
      );
  }
  AssignFormNumbersData(response: any) {

    //#region Get details from formnumberproperties table
    this.objFormnumbers.CmpCode = this.response['Result'][0].CmpCode;
    this.objFormnumbers.PromoCodeProp = this.response['Result'][0].PromoCodeProp;
    this.objFormnumbers.ReferralCodeProp = this.response['Result'][0].ReferralCodeProp;
    this.objFormnumbers.GroupCode = this.response['Result'][0].GroupCode;
    this.objFormnumbers.AgentName = this.response['Result'][0].AgentName;
    this.objFormnumbers.AgentProductList = this.response['Result'][0].AgentProductList;
    this.objFormnumbers.AgentProductListSpanish = this.response['Result'][0].AgentProductListSpanish;
    this.objFormnumbers.EnrollmentFee = this.response['Result'][0].EnrollmentFee;
    this.objFormnumbers.ApplicationName = this.response['Result'][0].ApplicationName;
    this.objFormnumbers.MarketingPlanName = this.response['Result'][0].MarketingPlanName;
    this.objFormnumbers.MarketingPlanNameSpanish = this.response['Result'][0].MarketingPlanNameSpanish;
    //this.objFormnumbers.PromoCode = this.response['Result'][0].PromoCode;
    this.objFormnumbers.StyleSheet = this.response['Result'][0].StyleSheet;
    this.objFormnumbers.EffDtSelectionProp = this.response['Result'][0].EffDtSelectionProp;
    this.objFormnumbers.GoogleAnalyticsUAcode = this.response['Result'][0].GoogleAnalyticsUAcode !== null ? this.response['Result'][0].GoogleAnalyticsUAcode : ""; 
    this.userService.FormNumberProperty(this.objFormnumbers);
    //#endregion

    //#region Apply GoogleAnalytics UA Code with page name if exists for the client
    if(this.objFormnumbers.GoogleAnalyticsUAcode !== null && this.objFormnumbers.GoogleAnalyticsUAcode.length > 0)
    {
      this.googleAnalyticsService.gaTriggerPageView(this.objFormnumbers.GoogleAnalyticsUAcode,'StepOne Page! ' + this.objFormnumbers.AgentName);
    }    
      //#endregion

    //#region Get Coverage details
    const GetRatesByCvgTypeRes = [];
    for (let i = 0; i < response['Result'][0].GetRatesByCvgType.length; i++) {
      GetRatesByCvgTypeRes.push(response['Result'][0].GetRatesByCvgType[i]);
    }
    this.objRates = GetRatesByCvgTypeRes;
    console.log(this.objRates);
    //#endregion

    //#region chcek property field for PromoCode, ReferralCode and EffectiveDt Selection field 
    if (this.objFormnumbers.PromoCodeProp.toString().toUpperCase() == 'SHOW' || this.objFormnumbers.PromoCodeProp.toString().toUpperCase() == 'SHOWREQUIRED') {
      this.bPromocode = true;
    }
    if (this.objFormnumbers.ReferralCodeProp.toString().toUpperCase() == 'SHOW' || this.objFormnumbers.ReferralCodeProp.toString().toUpperCase() == 'SHOWREQUIRED') {
      this.bReferralCode = true;
    }
    if (this.objFormnumbers.EffDtSelectionProp.toString().toUpperCase() == 'SHOW' || this.objFormnumbers.EffDtSelectionProp.toString().toUpperCase() == 'SHOWREQUIRED') {
      this.bEffDtSelection = true;
    }
    //#endregion
  }

  //#region Calling GetFormNumberDetails API to fetch formnumberscode
  restItemsServiceGetRestItems() {
    let headers = new HttpHeaders();
    headers = headers.set('x-api-key', 'W3y2ZUFQSVNlcnZpY2VzOkphbjIwMNf=');
    this.objFormnumbers.WebsiteURL = 'www.cidvt14.dentalsolutions.com';
    return this.http
      .post(this.rootUrl, this.objFormnumbers, { headers: headers })
      .pipe(map(data => data));
  }
  //#endregion

  //#region Calling GetValidation API to fetch formnumberscode
  restItemsServiceGetValidation() {
    return this.http.get(this.rootGetValidationUrl)
      .pipe(map(data => data));
  }
  //#endregion

  constructor(private userService: UserService, private route: ActivatedRoute, private router: Router, private googleAnalyticsService: GoogleAnalyticsService,
    private http: HttpClient, appComp: AppComponent) {
    super(userService);
    this.objFormnumbers = appComp.Formnumbers;
    this.objValidationRules = appComp.Validation;
    this.Rates = appComp.rates;
    //this.objRates = appComp.cvgrates;
    this.bEnrollmentFee = false;
    this.bPromocode = false;
    this.bReferralCode = false;
    this.bbtnStepOne = false;
    this.bValidPromoCode = true;
    this.bValidReferralCode = true;
    this.bReqEffDt = true;
    this.bReqPromoCode = true;
    this.bReqReferralCode = true;
  }

  ngOnInit() {
    this.bPageValid = true;
    this.CurrDt = new Date();
    this.NextMonthDt = new Date();
    this.NextMonthDt.setMonth(this.NextMonthDt.getMonth() + 1);
    this.getRestItems();
    this.getValidationRules();
    super.setStep(Activesteps.stepone);
  }

  //Continue with step2 once page validation get success
  continueToStep2() {
    this.ValidateRequiredFields();
    if (this.bPageValid) {
      this.userService.Products(this.Rates);
      this.router.navigate(['steptwo']);
    }

  }

  //Method to be called on radio button change event 
  onChange(sCvgType: string, sBilling: string, sEnrollment: string, sFrequency: string, event) {
    this.CvgType = sCvgType;
    this.CvgRate = sBilling;
    this.Frequency = sFrequency;
    this.Rates.EnrollmentFee = sEnrollment;
    this.bEnrollmentFee = true;
    this.Rates.CvgType = this.CvgType;
    this.Rates.CvgRates = this.CvgRate;
    this.Rates.Frequency = this.Frequency;
    this.bbtnStepOne = !event.checked;
    this.checkedevent = event;
  }


  //Method to validate Promocode 
  ValidatePromoCode(Promocode): void {
    for (let i = 0; i < this.objValidate.length; i++) {
      if (this.objValidate[i].FieldName.toString().toUpperCase() == "PROMOCODE") {
        var regex = new RegExp(this.objValidate[i].RegExpression);
        this.bPageValid = this.bValidPromoCode = regex.test(Promocode);
        this.objFormnumbers.PromoCode = Promocode;
      }
    }
    if (Promocode == "" && this.objFormnumbers.PromoCodeProp.toString().toUpperCase() == 'SHOWREQUIRED') {
      this.bPageValid = this.bReqPromoCode = false;
      this.bPageValid = this.bValidPromoCode = true;
      this.bbtnStepOne = false;
    }
    else {
      this.objFormnumbers.PromoCode = Promocode;
      this.bPageValid = this.bReqReferralCode = true;
      this.bbtnStepOne = true;
    }
  }

  //Method to validate ReferralCode 
  ValidateReferralCode(ReferralCode): void {
    for (let i = 0; i < this.objValidate.length; i++) {
      if (this.objValidate[i].FieldName.toString().toUpperCase() == 'REFERRALCODE') {
        var regex = new RegExp(this.objValidate[i].RegExpression);
        this.bPageValid = this.bValidReferralCode = regex.test(ReferralCode);
      }
    }
    if (ReferralCode == "" && this.objFormnumbers.ReferralCodeProp.toString().toUpperCase() == 'SHOWREQUIRED') {
      this.bPageValid = this.bReqReferralCode = false;
      this.bValidReferralCode = true;
      this.bbtnStepOne = false;
    }
    else {
      this.objFormnumbers.ReferralCode = ReferralCode;
      this.bPageValid = this.bReqReferralCode = true;
      this.bbtnStepOne = true;
    }
  }

  //Method to validate EffDtSelection 
  onSelect(EffDtSelection) {
    if (this.objFormnumbers.EffDtSelectionProp.toString().toUpperCase() == 'SHOWREQUIRED' && EffDtSelection == '- Start Date -') {
      this.bPageValid = this.bReqEffDt = false;
      this.bbtnStepOne = false;
    }
    else {
      this.objFormnumbers.EffectiveDate = EffDtSelection;
      this.bPageValid = this.bReqEffDt = true;
      this.bbtnStepOne = true;
    }

  }

  //method to bind dates to plan start dropdownlist
  // GetDate(CurrDt) {
  //   let sDate = this.CurrDt.toString().split("/");
  //   this.Day = parseInt(sDate[0]);
  //   this.Month = parseInt(sDate[1]);
  //   this.year = parseInt(sDate[2]);
  //   this.objFormnumbers.PlanStartDate = this.Month + "/" + this.Day + "/" + this.year;
  //   this.FirstOfThisMonth = this.Month + "/01/" + this.year;
  //   this.FirstOfNextMonth = (this.Month + 1) + "/01/" + this.year;

  // }

  //method validates required fields and set page flage to true or false for continuing to next step 
  ValidateRequiredFields() {
    if (this.checkedevent == null) {
      this.bbtnStepOne = this.bPageValid = false;
    }
    else if (this.objFormnumbers.EffectiveDate == null && this.objFormnumbers.EffDtSelectionProp.toString().toUpperCase() == 'SHOWREQUIRED') {
      this.bbtnStepOne = this.bPageValid = this.bReqEffDt = false;

    }
    else if ((this.objFormnumbers.ReferralCode == null && this.objFormnumbers.ReferralCodeProp.toString().toUpperCase() == 'SHOWREQUIRED') || (!this.bValidReferralCode)) {
      this.bbtnStepOne = this.bPageValid = this.bReqReferralCode = false;
    }
    else if ((this.objFormnumbers.PromoCode == null && this.objFormnumbers.PromoCodeProp.toString().toUpperCase() == 'SHOWREQUIRED') || (!this.bValidPromoCode)) {
      this.bbtnStepOne = this.bPageValid = this.bReqPromoCode = false;
    }
    else {
      this.bbtnStepOne = this.bPageValid = this.bReqEffDt = this.bReqPromoCode = this.bReqReferralCode = true;
    }
  }
}
