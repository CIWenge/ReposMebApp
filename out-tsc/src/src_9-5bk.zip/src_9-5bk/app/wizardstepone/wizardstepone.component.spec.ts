import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WizardsteponeComponent } from './wizardstepone.component';

describe('WizardsteponeComponent', () => {
  let component: WizardsteponeComponent;
  let fixture: ComponentFixture<WizardsteponeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WizardsteponeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WizardsteponeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
