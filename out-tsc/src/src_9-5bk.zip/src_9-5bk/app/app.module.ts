
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MessagesComponent } from './messages/messages.component';
import { AppRoutingModule } from './app-routing.module';
import { WizardsteponeComponent } from './wizardstepone/wizardstepone.component';
import { WizardsteptwoComponent } from './wizardsteptwo/wizardsteptwo.component';
import { WizardstepthreeComponent } from './wizardstepthree/wizardstepthree.component';
import { WizardstepfourComponent } from './wizardstepfour/wizardstepfour.component';
import { WizardstepfiveComponent } from './wizardstepfive/wizardstepfive.component';
import { UserService } from '../Shared/User.service';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

@NgModule({
  declarations: [
    AppComponent,
    MessagesComponent,
    WizardsteponeComponent,
    WizardsteptwoComponent,
    WizardstepthreeComponent,
    WizardstepfourComponent,
    WizardstepfiveComponent,
    HeaderComponent,
    FooterComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule
    
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }

