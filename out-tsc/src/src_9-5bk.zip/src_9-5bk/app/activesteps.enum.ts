export enum Activesteps {
    
  stepone = 1,
  steptwo = 2,
  stepthree = 3,
  stepfour = 4,
  stepfive = 5
   
}
