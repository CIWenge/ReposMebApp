import { Component, OnInit } from '@angular/core';
import {
  Member, FormNumberDetails, Product, MemberDependentPayment, FormNumbers,
  GetRatesByCvgType, MemberPaymentMethod, ValidationRules
} from '../Shared/User.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MemberApp';
  member: Member = new Member();
  memberDep: MemberDependentPayment = new MemberDependentPayment();
  // dependent: Dependent = new Dependent();
  cssClass: string;
  FormNumbersInfo: FormNumberDetails = new FormNumberDetails();
  memberPaymentMethod: MemberPaymentMethod = new MemberPaymentMethod();
  Formnumbers: FormNumbers = new FormNumbers();
  Validation: ValidationRules = new ValidationRules();
  productMethod: Product = new Product();
  rates: GetRatesByCvgType = new GetRatesByCvgType();
  public CREDIT: boolean;
  public BANK: boolean;
  public PAYPAL: boolean;
  public ActivePayment : string;
  
  constructor() {
    this.ActivePayment = 'credit';
    this.CREDIT = true;
    this.BANK = this.PAYPAL = false;
    this.member.FirstName = '';
    this.member.LastName = '';
    this.member.MailingAddress = '';
    this.member.City = '';
    this.member.StateCode = '';
    this.member.ZipCode = '';
    this.member.HomePhone = '';
    this.member.WorkPhone = '';
    this.member.MobilePhone = '';
    this.member.Email = '';
    this.rates.CvgType = '';
    this.rates.CvgRates = '';
    this.rates.EnrollmentFee = '';
    this.rates.Frequency = '';
  }


}
