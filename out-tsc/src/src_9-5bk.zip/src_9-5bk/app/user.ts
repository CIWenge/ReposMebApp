export class User {
  id: number;
  name: string;
  role: string;
}

export class Mbr {
  FirstName: string;
  LastName: string;
  MailingAddress: string;
  City: string;
  State: string;
  ZipCode: string;
  HomePhone: string;
  WorkPhone: string;
  MobilePhone: string;
  Gender: string;
  Email: string;
  ConfirmEmail: string;
}
/*
export class FormNumberDetails {
  WebsiteURL: string;
  MonthlyRate: string;
  QuarterlyRate: string;
  SemiAnnualRate: string;
  AnnualRate: string;
  CvgType: string;
  FormNumbersCode: string;
  AgentName: string;
  AgentProductList: string;
  AgentProductListSpanish: string;
  EnrollmentFee: string;
  ApplicationName: string;
  Rate: string;
}

export class Billing {
  CoverageType: string;
  CoverageRate: string;
  CoverageFrequency: string;
}

export class GetRatesByCvgType {
  MonthlyRate: string;
  QuarterlyRate: string;
  SemiAnnualRate: string;
  AnnualRate: string;
  CvgType: string;
}
*/
export class MemberPaymentMethod {
  CardActType: string;
  NameofBank: string;
  NameonAccount: string;
  ActNum: string;
  RoutingNum: string;
  TransactionStatus: string;
}
