import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GetRatesByCvgType } from '../../Shared/User.model';
import { AppComponent } from '../app.component';
import { MemberPaymentMethod, ValidationRules } from '../../Shared/User.model';
import { UserService } from '../../Shared/User.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { CommonComponent } from '../common/common';
import { Activesteps } from '../activesteps.enum';
import { GoogleAnalyticsService } from '../../Shared/GoogleAnalytics.service';

@Component({
  selector: 'app-wizardstepthree',
  templateUrl: './wizardstepthree.component.html',
  styleUrls: ['./wizardstepthree.component.css']
})

export class WizardstepthreeComponent extends CommonComponent implements OnInit {
  title = 'Step 3: Payment';
  public BANK: boolean;
  public CREDIT: boolean;
  public PAYPAL: boolean;
  public bValidNameonAccount: boolean;
  public bValidCARDExpDate: boolean;
  public bValidCardNumber: boolean;
  public bPageisValid: boolean;
  public bValidCardActType : boolean;
  public bValidNameofBank : boolean;
  public bValidCardHolderName : boolean;
  public bValidRoutingNum : boolean;
  public bValidActNum : boolean;
  objValidate: ValidationRules[];
  rateObj: GetRatesByCvgType;
  Rates: GetRatesByCvgType;
  paymentdetails: MemberPaymentMethod = new MemberPaymentMethod();
  public activeTab : string;

  constructor(private userService: UserService, private route: ActivatedRoute, private router: Router,public appComp: AppComponent, private googleAnalyticsService: GoogleAnalyticsService,
    private http: HttpClient) {
    super(userService);
    this.CREDIT = appComp.CREDIT;
    this.BANK = appComp.BANK;
    this.PAYPAL = appComp.PAYPAL;
    this.Rates = appComp.rates;
    this.paymentdetails = appComp.memberPaymentMethod;
    this.activeTab = appComp.ActivePayment;
  }

  ngOnInit() {
    //alert('ngonit step3 '+ Activesteps.stepthree);
    this.googleAnalyticsService.gaTriggerPageView(this.userService.objFormnumbers.GoogleAnalyticsUAcode,'StepThree Payment Page! ' + this.userService.objFormnumbers.AgentName);
    super.setStep(Activesteps.stepthree);
    this.bValidCardActType = this.bValidNameofBank = this.bValidRoutingNum = this.bValidActNum = true;
    this.bPageisValid = true;
    this.getValidationRules();
  }

  readonly rootGetValidationUrl = 'http://10.74.11.102/CareAPIServices/GetValidationRules';
  responsevalidation: any = {};
  getValidationRules(): void {
    this.restItemsServiceGetValidation()
      .subscribe(
        restItems => {
          this.responsevalidation = restItems;
          this.AssignValidationRules(this.responsevalidation);
        }
      );
  }

  //#region Calling GetValidation API to fetch Validation rules
  restItemsServiceGetValidation() {
    return this.http.get(this.rootGetValidationUrl)
      .pipe(map(data => data));
  }
  //#endregion

  AssignValidationRules(ValidationRuleRes: any) {
    const Validation = [];
    for (let i = 0; i < ValidationRuleRes['Result'].length; i++) {
      Validation.push(ValidationRuleRes['Result'][i]);
    }
    this.objValidate = Validation;
    //console.log(this.objValidate);
  }

  //Bank draft Field level validation
  ValidateBankDraftDetails(paymentdetails): void {
    for (let i = 0; i < this.objValidate.length; i++) {
      var regex = new RegExp(this.objValidate[i].RegExpression);
      switch (this.objValidate[i].FieldName.toString().toUpperCase()) {

        case "CARDACTTYPE":
          this.bValidCardActType = regex.test(paymentdetails.CardActType);
          this.bPageisValid = this.bValidCardActType == false ? false : this.bPageisValid;
          break;

        case "NAMEOFBANK":
          this.bValidNameofBank = regex.test(paymentdetails.bValidNameofBank);
          this.bPageisValid = this.bValidNameofBank == false ? false : this.bPageisValid;
          break;

        case "NAMEONACCOUNT":
          this.bValidNameonAccount = regex.test(paymentdetails.NameonAccount);
          this.bPageisValid = this.bValidNameonAccount == false ? false : this.bPageisValid;
          break;

        case "ROUTINGNUM":
          this.bValidRoutingNum = regex.test(paymentdetails.RoutingNum);
          this.bPageisValid = this.bValidRoutingNum == false ? false : this.bPageisValid;
          break;

          case "ACTNUM":
          this.bValidActNum = regex.test(paymentdetails.ActNum);
          this.bPageisValid = this.bValidActNum == false ? false : this.bPageisValid;
          break;
      }
    }
  }

  //Credit card Field level validation
  ValidateCreditCardDetails(paymentdetails): void {
    for (let i = 0; i < this.objValidate.length; i++) {      
      switch (this.objValidate[i].FieldName.toString().toUpperCase()) {
        case "CARDHOLDERNAME":
          var regex = new RegExp(this.objValidate[i].RegExpression);        
          this.bValidCardHolderName = regex.test(paymentdetails.CardHolderName);          
          this.bPageisValid = this.bValidCardHolderName == false ? false : this.bPageisValid;         
          break;

        case "CARDNUMBER":
          var regex = new RegExp(this.objValidate[i].RegExpression);
          this.bValidCardNumber = regex.test(paymentdetails.CardNumber);          
          this.bPageisValid = this.bValidCardNumber == false ? false : this.bPageisValid;          
          break;

        case "CARDEXPDATE":
          var regex = new RegExp(this.objValidate[i].RegExpression);
          this.bValidCARDExpDate = regex.test(paymentdetails.CardExpDate);
          this.bPageisValid = this.bValidCARDExpDate == false ? false : this.bPageisValid;
          break;
      }
    }
    alert(this.bPageisValid);
  }

  continueToStep4(paymentdetails) {
    //this.ValidateCreditCardDetails(paymentdetails);
   // if (this.bPageisValid) {
      this.userService.MemberPaymentMethod(paymentdetails);
      this.router.navigate(['stepfour']);
    //}
  }

  returnToStep3() {
    this.router.navigate(['steptwo']);
  }
 

  credit(activeTab){
    this.activeTab = this.appComp.ActivePayment = activeTab;
    this.CREDIT = this.appComp.CREDIT = true;
    this.BANK = this.PAYPAL = this.appComp.BANK = this.appComp.PAYPAL = false;
  }
  bank(activeTab){
    this.activeTab = this.appComp.ActivePayment = activeTab;
    this.BANK = this.appComp.BANK = true;
    this.PAYPAL = this.CREDIT = this.appComp.CREDIT = this.appComp.PAYPAL = false;
  }
  paypal(activeTab){
    this.activeTab = this.appComp.ActivePayment = activeTab;
    this.CREDIT = this.BANK = this.appComp.BANK = this.appComp.CREDIT =false;
    this.PAYPAL = this.appComp.PAYPAL = true;
  }
}
