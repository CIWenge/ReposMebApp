import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WizardstepthreeComponent } from './wizardstepthree.component';

describe('WizardstepthreeComponent', () => {
  let component: WizardstepthreeComponent;
  let fixture: ComponentFixture<WizardstepthreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WizardstepthreeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WizardstepthreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
