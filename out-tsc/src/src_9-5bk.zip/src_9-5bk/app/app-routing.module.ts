  import { NgModule } from '@angular/core';
  import { CommonModule } from '@angular/common';
  import { RouterModule, Routes} from '@angular/router';
  import { fromEventPattern } from 'rxjs';
  import { WizardsteponeComponent } from './wizardstepone/wizardstepone.component';
  import { WizardsteptwoComponent } from './wizardsteptwo/wizardsteptwo.component';
  import { WizardstepthreeComponent } from './wizardstepthree/wizardstepthree.component';
import { WizardstepfourComponent } from './wizardstepfour/wizardstepfour.component';
import { WizardstepfiveComponent } from './wizardstepfive/wizardstepfive.component';


  const routes: Routes = [
  {path:'',component:WizardsteponeComponent},
  {path:'steptwo',component:WizardsteptwoComponent},
  {path:'stepthree',component:WizardstepthreeComponent},
  {path:'stepfour',component:WizardstepfourComponent},
  {path:'stepfive',component:WizardstepfiveComponent}
  ];

  @NgModule({
    imports: [ RouterModule.forRoot(routes) ],
    exports: [ RouterModule ]
  })

  export class AppRoutingModule { }
