import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppComponent } from '../app.component';
import { Member, MemberDependentPayment, MemberPaymentMethod, Product, GetRatesByCvgType } from '../../Shared/User.model';
import { FormNumberDetails} from '../../Shared/User.model';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { map } from 'rxjs/operators';
import { CommonComponent } from '../common/common';
import { Activesteps } from '../activesteps.enum';
import { UserService } from '../../Shared/User.service';
import { GoogleAnalyticsService } from '../../Shared/GoogleAnalytics.service';

@Component({
  selector: 'app-wizardstepfour',
  templateUrl: './wizardstepfour.component.html',
  styleUrls: ['./wizardstepfour.component.css']
})
export class WizardstepfourComponent extends CommonComponent implements OnInit {
  title = 'Step 4: Review order';
  ombrdepobj: MemberDependentPayment;
  mbrObj: Member;
  rateObj: GetRatesByCvgType;
   pymntObj: MemberPaymentMethod;
  prdctObj: Product;

  readonly rootUrl = 'http://localhost:65240/AddMember';
  objFormNumberDetails: FormNumberDetails;
  user: Member;
  Rates: GetRatesByCvgType;
  pymnt: MemberPaymentMethod;
  prdt: Product;

  constructor(private userService: UserService, private route: ActivatedRoute,private googleAnalyticsService: GoogleAnalyticsService,
    private http: HttpClient, private router: Router, appComp: AppComponent) {

    super(userService);
    this.ombrdepobj = userService.ombrdepobj;
    this.mbrObj = this.ombrdepobj.Member;
    this.user = this.ombrdepobj.Member;
    this.objFormNumberDetails = userService.objFormNumberDetails;
    this.rateObj = this.objFormNumberDetails.GetRatesByCvgType;
    this.pymntObj = this.ombrdepobj.MemberPaymentMethod;
    this.pymnt = this.ombrdepobj.MemberPaymentMethod;
    this.prdctObj = this.ombrdepobj.Product;
    this.prdt = this.ombrdepobj.Product;
    this.Rates = appComp.rates;


  }

  ngOnInit() {
   // alert("ngOnInit stepfour "+Activesteps.stepfour);
    super.setStep(Activesteps.stepfour);
    this.googleAnalyticsService.gaTriggerPageView(this.userService.objFormnumbers.GoogleAnalyticsUAcode,'StepFour Review order Page! ' + this.userService.objFormnumbers.AgentName);
   // alert(super.setStep(Activesteps.stepfour));
  }


  response: any = {};
  getRestItems(): void {
    this.restItemsServiceGetRestItems()
      .subscribe(
        restItems => {
          this.response = restItems;
          this.AssignFormNumbersData(this.response);
          console.log(this.response);

        }
      );
  }




  AssignFormNumbersData(response: any) {
   // this.pymntObj.TransactionStatus = this.response['Result'][0].TransactionStaus;
    // this.pymntObj.TransactionStatus = 'US';
}


returnToStep3() {
  this.router.navigate(['stepthree']);
  let headers = new HttpHeaders();
  headers = headers.set('x-api-key', 'QBI52751245CC');

  this.http.post(this.rootUrl, this.ombrdepobj, {headers: headers}).subscribe(
    (data) => {
        console.log(data);
    });
}

restItemsServiceGetRestItems() {

let headers = new HttpHeaders();
  headers = headers.set('x-api-key', 'QBI52751245CC');
  return this.http
    .post(this.rootUrl, this.ombrdepobj, { headers: headers })
    .pipe(map(data => data));

}


continueToStep5() {

  this.router.navigate(['stepfive']);

}

}

